export const _siteConfig = {
  name: "TechstaHR",
  domain: "techstahr.com",
  desc: "Outsource Tech Talent. Manage Projects. Track Work Seamlessly.",
  menuLinks: [
    { title: "Link 1", href: "#link-1" },
    { title: "Link 2", href: "#link-2" },
    { title: "Link 3", href: "#link-3", extra: true },
  ],
};

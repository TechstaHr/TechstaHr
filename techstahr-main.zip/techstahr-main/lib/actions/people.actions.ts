import axios from "axios";
import Cookies from "js-cookie";
import { handleError } from "../utils";

const url = "https://techstahr.onrender.com/api/v1";

export const getPeopleStats = async () => {
  const token = Cookies.get("token");

  if (!token) throw new Error("Authentication token not found.");

  try {
    const response = await axios.get(`${url}/people/stats`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    return response.data;
  } catch (error: any) {
    handleError("Get Stats", error);
  }
};

export const getRoles = async () => {
  const token = Cookies.get("token");

  if (!token) throw new Error("Authentication token not found.");

  try {
    const response = await axios.get(`${url}/people/roles`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    return response.data;
  } catch (error: any) {
    handleError("Get Roles", error);
  }
};

export const getDirectories = async () => {
  const token = Cookies.get("token");

  if (!token) throw new Error("Authentication token not found.");

  try {
    const response = await axios.get(`${url}/people/directory`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    return response.data;
  } catch (error: any) {
    handleError("Get Directory", error);
  }
};

export const getPerformance = async () => {
  const token = Cookies.get("token");

  if (!token) throw new Error("Authentication token not found.");

  try {
    const response = await axios.get(`${url}/people/performance`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    return response.data;
  } catch (error: any) {
    handleError("Get Performance", error);
  }
};

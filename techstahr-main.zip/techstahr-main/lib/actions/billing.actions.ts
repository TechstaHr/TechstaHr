// lib/actions/billing.actions.ts

import axios from "axios";
import Cookies from "js-cookie";
import { handleError } from "../utils";
import { BillingInfo } from "@/types";

const url = "https://techstahr.onrender.com/api/v1/billing";

// Create Billing Info (POST)
export const createBillingInfo = async (data: BillingInfo) => {
  const token = Cookies.get("token");
  if (!token) throw new Error("Authentication token not found.");

  try {
    const response = await axios.post(url, data, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return response.data;
  } catch (error: any) {
    handleError("Create Billing Info", error);
  }
};

// Get Billing Info (GET)
export const getBillingInfo = async () => {
  const token = Cookies.get("token");
  if (!token) throw new Error("Authentication token not found.");

  try {
    const response = await axios.get(url, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return response.data;
  } catch (error: any) {
    handleError("Get Billing Info", error);
  }
};

// Update Billing Info (PUT)
export const updateBillingInfo = async (data: BillingInfo) => {
  const token = Cookies.get("token");
  if (!token) throw new Error("Authentication token not found.");

  try {
    const response = await axios.put(url, data, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return response.data;
  } catch (error: any) {
    handleError("Update Billing Info", error);
  }
};

import axios from "axios";
import Cookies from "js-cookie";
import { handleError } from "../utils";

const url = "https://techstahr.onrender.com/api/v1";

// 1. Update Screenshot Settings
export const updateScreenshotSettings = async ({
  taskId,
  enableScreenshot,
  screenshotIntervalMinutes,
}: {
  taskId: string;
  enableScreenshot: boolean;
  screenshotIntervalMinutes: number;
}) => {
  const token = Cookies.get("token");

  if (!token) {
    throw new Error("Authentication token not found.");
  }

  try {
    const response = await axios.put(
      `${url}/screenshot/${taskId}/screenshot-settings`,
      {
        enableScreenshot,
        screenshotIntervalMinutes,
      },
      {
        headers: { Authorization: `Bearer ${token}` },
      },
    );
    return response.data;
  } catch (error: any) {
    handleError("Update Screenshot Settings", error);
  }
};

// 2. Get All Screenshots
export const getAllScreenshots = async (taskId: string) => {
  const token = Cookies.get("token");

  if (!token) {
    throw new Error("Authentication token not found.");
  }

  try {
    const response = await axios.get(
      `${url}/screenshot/${taskId}/screenshots`,
      {
        headers: { Authorization: `Bearer ${token}` },
      },
    );
    return response.data;
  } catch (error: any) {
    handleError("Get All Screenshots", error);
  }
};

// 3. Stop Screenshot Capture
export const stopScreenshotCapture = async (taskId: string) => {
  const token = Cookies.get("token");

  if (!token) {
    throw new Error("Authentication token not found.");
  }

  try {
    const response = await axios.put(
      `${url}/screenshot/${taskId}/stop-screenshot`,
      {},
      {
        headers: { Authorization: `Bearer ${token}` },
      },
    );
    return response.data;
  } catch (error: any) {
    handleError("Stop Screenshot Capture", error);
  }
};

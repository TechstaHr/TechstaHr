import { TimesheetData } from "@/types";
import axios from "axios";
import Cookies from "js-cookie";
import { handleError } from "../utils";

const url = "https://techstahr.onrender.com/api/v1";

// Submit timesheet
export const submitTimesheet = async (timeLogId: string) => {
  const token = Cookies.get("token");

  if (!token) {
    throw new Error("Authentication token not found.");
  }

  try {
    const response = await axios.post(
      `${url}/project/submit-timesheet`,
      timeLogId,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      },
    );

    return response.data;
  } catch (error: any) {
    handleError("Create timesheet", error);
  }
};

// Get timesheet
export const getTimesheets = async () => {
  const token = Cookies.get("token");

  if (!token) {
    throw new Error("Authentication token not found.");
  }

  try {
    const response = await axios.get(`${url}/project/timesheets`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    return response.data;
  } catch (error: any) {
    handleError("Get timesheets", error);
  }
};

export const getWeeklyTimeSheet = async (): Promise<TimesheetData> => {
  const token = Cookies.get("token");

  if (!token) throw new Error("Authentication token not found.");

  try {
    const response = await axios.get(`${url}/project/weekly-timesheet`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    return response.data;
  } catch (error: any) {
    handleError("Get weekly timesheets", error);
  }
};

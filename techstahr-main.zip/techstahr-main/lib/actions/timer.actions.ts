import { TimesheetData } from "@/types";
import axios from "axios";
import Cookies from "js-cookie";

const url = "https://techstahr.onrender.com/api/v1";

// POST: Start timer for a project
export const startProjectTimer = async (projectId: string) => {
  const token = Cookies.get("token");

  if (!token) throw new Error("Authentication token not found.");

  try {
    const response = await axios.post(
      `${url}/project/timer/start/${projectId}`,
      {},
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      },
    );

    return response.data;
  } catch (error: any) {
    if (axios.isAxiosError(error) && error.response) {
      console.error("Error starting timer:", error.response.data);
      throw error.response.data;
    }
    throw error;
  }
};

// POST: Stop timer for a project
export const stopProjectTimer = async (projectId: string) => {
  const token = Cookies.get("token");

  if (!token) throw new Error("Authentication token not found.");

  try {
    const response = await axios.post(
      `${url}/project/timer/stop/${projectId}`,
      {},
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      },
    );

    return response.data;
  } catch (error: any) {
    if (axios.isAxiosError(error) && error.response) {
      console.error("Error stopping timer:", error.response.data);
      throw error.response.data;
    }
    throw error;
  }
};

export const getTimeSheet = async (): Promise<TimesheetData> => {
  const token = Cookies.get("token");

  if (!token) throw new Error("Authentication token not found.");

  try {
    const response = await axios.get(`${url}/project/weekly-timesheet`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    return response.data;
  } catch (error: any) {
    if (axios.isAxiosError(error) && error.response) {
      console.error("Error stopping timer:", error.response.data);
      throw error.response.data;
    }
    throw error;
  }
};

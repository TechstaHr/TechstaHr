import { _user, ClockInResponse, ClockOutResponse } from "@/types";
import axios from "axios";
import Cookies from "js-cookie";
import { handleError } from "../utils";

const url = "https://techstahr.onrender.com/api/v1";

// User Profile Queries

export const getUserProfile = async () => {
  const token = Cookies.get("token");

  if (!token) {
    throw new Error("Authentication token not found.");
  }

  try {
    const response = await axios.get(`${url}/user/profile`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return response.data;
  } catch (error: any) {
    handleError("Get profile", error);
  }
};

export const getAllUsers = async () => {
  const token = Cookies.get("token");

  if (!token) {
    throw new Error("Authentication token not found.");
  }

  try {
    const response = await axios.get(`${url}/user/users`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return response.data;
  } catch (error: any) {
    handleError("Get users", error);
  }
};

// user.actions.ts
export const editUserProfile = async (formData: FormData) => {
  const token = Cookies.get("token");

  if (!token) {
    throw new Error("Authentication token not found.");
  }

  try {
    const response = await axios.put(`${url}/user/profile`, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data;
  } catch (error: any) {
    handleError("Edit profile", error);
  }
};

export const changeUserRole = async (id: string, role: string) => {
  const token = Cookies.get("token");

  if (!token) {
    throw new Error("Authentication token not found.");
  }

  try {
    const response = await axios.put(
      `${url}/user/role/${id}`,
      { role },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      },
    );
    return response.data;
  } catch (error: any) {
    handleError("Change role", error);
  }
};

/**
 * Deletes a specific user by ID
 * @param userId - The ID of the user to delete
 */
export const deleteUserById = async (userId: string) => {
  const token = Cookies.get("token");

  if (!token) throw new Error("Authentication token not found.");

  try {
    const response = await axios.delete(`${url}/user/delete/${userId}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    return response.data;
  } catch (error: any) {
    handleError("deleteUserById", error);
  }
};

/**
 * Deletes the currently authenticated user
 */
export const deleteCurrentUser = async () => {
  const token = Cookies.get("token");

  if (!token) throw new Error("Authentication token not found.");

  try {
    const response = await axios.delete(`${url}/user/delete`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    return response.data;
  } catch (error: any) {
    handleError("deleteCurrentUser", error);
  }
};

export const clockIn = async (
  projectId: string,
  startTime: string,
): Promise<ClockInResponse> => {
  const token = Cookies.get("token");
  if (!token) throw new Error("Authentication token not found.");

  try {
    const response = await axios.post(
      `${url}/user/clock-in/${projectId}`,
      { startTime },
      { headers: { Authorization: `Bearer ${token}` } },
    );
    return response.data;
  } catch (error: any) {
    handleError(`Clock in to project ${projectId}`, error);
  }
};

export const clockOut = async (
  projectId: string,
): Promise<ClockOutResponse> => {
  const token = Cookies.get("token");
  if (!token) throw new Error("Authentication token not found.");

  try {
    const response = await axios.post(
      `${url}/user/clock-out/${projectId}`,
      {},
      { headers: { Authorization: `Bearer ${token}` } },
    );
    return response.data;
  } catch (error: any) {
    handleError(`Clock out of project ${projectId}`, error);
  }
};

export const adminClockOut = async (
  userId: string,
  projectId: string,
): Promise<ClockOutResponse> => {
  const token = Cookies.get("token");
  if (!token) throw new Error("Authentication token not found.");

  try {
    const response = await axios.post(
      `${url}/user/admin-clock-out/${userId}/${projectId}`,
      {},
      { headers: { Authorization: `Bearer ${token}` } },
    );
    return response.data;
  } catch (error: any) {
    handleError(
      `Admin clock out for user ${userId} on project ${projectId}`,
      error,
    );
  }
};

export const getZones = async () => {
  const token = Cookies.get("token");

  if (!token) throw new Error("Authentication token not found.");

  try {
    const response = await axios.get(`${url}/user/zones`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return response.data;
  } catch (error: any) {
    handleError(`Get zones`, error);
  }
};

export const updateRegion = async (region: string) => {
  const token = Cookies.get("token");

  if (!token) throw new Error("Authentication token not found.");

  try {
    const response = await axios.put(
      `${url}/user/update-region`,
      { region },
      {
        headers: { Authorization: `Bearer ${token}` },
      },
    );
    return response.data;
  } catch (error: any) {
    handleError(`Get zones`, error);
  }
};

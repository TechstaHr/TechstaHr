export interface NavItem {
  title: string;
  href?: string;
  extra?: boolean;
  disabled?: boolean;
  external?: boolean;
}

"use client";

import { useRef } from "react";
import html2canvas from "html2canvas";
import { ScreenShareIcon, UploadIcon } from "lucide-react";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import ProductivityLineChart from "./ProductivityLineChart";
import { getUserProductivity } from "@/lib/actions/productivity.actions";
import { useQuery } from "@tanstack/react-query";

type CardProps = React.ComponentProps<typeof Card>;

export function ProductivityCard({ className, ...props }: CardProps) {
  const cardRef = useRef<HTMLDivElement>(null);

  const { data, isLoading, isError } = useQuery({
    queryKey: ["userProductivity"],
    queryFn: getUserProductivity,
  });

  const transformedData =
    data?.productivity &&
    Object.entries(data.productivity).map(([day, value]) => ({
      name: day.slice(0, 3),
      productivity: value,
    }));

  const handleScreenshot = async () => {
    if (cardRef.current) {
      const canvas = await html2canvas(cardRef.current);
      const imgData = canvas.toDataURL("image/png");

      // Create a link to download the image
      const link = document.createElement("a");
      link.href = imgData;
      link.download = "productivity-chart.png";
      link.click();
    }
  };

  return (
    <Card
      ref={cardRef}
      className={cn("w-[380px] overflow-hidden lg:w-[720px]", className)}
      {...props}
    >
      <CardHeader className="w-full flex-row items-center justify-between p-4">
        <CardTitle>Productivity</CardTitle>
        <div className="flex items-center gap-4">
          <Button className="bg-transparent p-0 text-black shadow-none hover:bg-transparent">
            Export
            <UploadIcon />
          </Button>
          <Button
            className="bg-transparent p-0 text-black shadow-none hover:bg-transparent"
            onClick={handleScreenshot}
          >
            Screenshot
            <ScreenShareIcon className="ml-1" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <p className="text-center text-sm">Loading chart...</p>
        ) : isError ? (
          <p className="text-center text-sm text-red-500">
            Failed to load productivity data.
          </p>
        ) : (
          <ProductivityLineChart data={transformedData} />
        )}
      </CardContent>
    </Card>
  );
}

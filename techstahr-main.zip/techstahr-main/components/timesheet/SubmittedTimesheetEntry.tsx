// components/SubmittedTimesheetEntry.tsx
"use client";

import React from "react";
import { Button } from "@/components/ui/button";
import { ClockIcon, Camera, Eye, User } from "lucide-react";
import { calculateDuration } from "@/lib/utils";

interface SubmittedTimesheetEntryProps {
  log: any;
}

export const formatTime = (dateString: string) => {
  return new Date(dateString).toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });
};

const SubmittedTimesheetEntry: React.FC<SubmittedTimesheetEntryProps> = ({
  log,
}) => {
  return (
    <div className="flex flex-col items-start justify-between gap-4 rounded-lg border border-green-200 bg-green-50 p-4 sm:flex-row sm:items-center">
      <div className="flex flex-1 items-start gap-3">
        <div className="flex h-10 w-10 items-center justify-center overflow-hidden rounded-full border bg-white">
          <User className="h-5 w-5 text-gray-600" />
        </div>
        <div className="flex-1">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:gap-4">
            <p className="font-medium text-gray-900">{log?.user?.full_name}</p>
            <p className="text-sm text-gray-600">{log?.project?.name}</p>
          </div>
          <div className="mt-1 flex flex-col gap-2 text-sm text-gray-600 sm:flex-row sm:items-center sm:gap-4">
            <div className="flex items-center gap-1">
              <ClockIcon className="h-4 w-4" />
              <span>
                {formatTime(log.start)} - {formatTime(log.end)}
              </span>
            </div>
            <div className="font-medium text-blue-600">
              {calculateDuration(log.start, log.end)}
            </div>
            {log?.screenshots?.length > 0 && (
              <div className="flex items-center gap-1">
                <Camera className="h-4 w-4" />
                <span>
                  {log.screenshots.length} screenshot
                  {log.screenshots.length > 1 ? "s" : ""}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
      <div className="flex gap-2">
        {/* <Button
          size="sm"
          variant="outline"
          onClick={() => window.open(log.link, "_blank")}
          className="hover:bg-blue-50"
        >
          <Eye className="mr-1 h-4 w-4" />
          View Details
        </Button> */}
      </div>
    </div>
  );
};

export default SubmittedTimesheetEntry;

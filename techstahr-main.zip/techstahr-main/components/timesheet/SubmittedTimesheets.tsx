// components/SubmittedTimesheets.tsx
"use client";

import React from "react";
import { Check } from "lucide-react";
import SubmittedTimesheetEntry from "./SubmittedTimesheetEntry";

interface SubmittedTimesheetsProps {
  submittedTimesheets: any;
  isLoading: boolean;
  isError: boolean;
}

const SubmittedTimesheets: React.FC<SubmittedTimesheetsProps> = ({
  submittedTimesheets,
  isLoading,
  isError,
}) => {
  return (
    <div className="space-y-4 rounded-lg border bg-white p-3 shadow-sm md:p-6">
      <h3 className="flex items-center gap-2 text-lg font-semibold">
        <Check className="h-5 w-5 text-green-600" />
        Submitted Timesheets
      </h3>

      {isLoading ? (
        <div className="py-8 text-center">
          <div className="mx-auto h-8 w-8 animate-spin rounded-full border-b-2 border-green-600"></div>
          <p className="mt-2 text-muted-foreground">
            Loading submitted timesheets...
          </p>
        </div>
      ) : isError ? (
        <p className="py-4 text-center text-red-500">
          Failed to load submitted timesheets.
        </p>
      ) : !submittedTimesheets?.submittedLogs?.length ? (
        <p className="py-4 text-center text-muted-foreground">
          No submitted timesheets found.
        </p>
      ) : (
        <div className="space-y-3">
          {submittedTimesheets.submittedLogs.map((log: any) => (
            <SubmittedTimesheetEntry key={log.logId} log={log} />
          ))}
        </div>
      )}
    </div>
  );
};

export default SubmittedTimesheets;

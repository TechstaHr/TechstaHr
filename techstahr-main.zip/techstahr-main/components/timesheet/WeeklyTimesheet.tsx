// components/WeeklyTimesheet.tsx
"use client";

import React from "react";
import { Button } from "@/components/ui/button";
import { Calendar, Send } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { submitTimesheet } from "@/lib/actions/timesheet.actions";
import toast from "react-hot-toast";
import WeeklyTimesheetProject from "./WeeklyTimesheetProject";

export const formatDate = (dateString: string) => {
  return new Date(dateString).toLocaleDateString("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
  });
};

interface WeeklyTimesheetProps {
  weeklyTimesheet: any;
  isLoading: boolean;
  isError: boolean;
  selectedTimeLogIds: string[];
  onTimeLogSelection: (logId: string) => void;
  onSubmitSuccess: () => void;
}

const WeeklyTimesheet: React.FC<WeeklyTimesheetProps> = ({
  weeklyTimesheet,
  isLoading,
  isError,
  selectedTimeLogIds,
  onTimeLogSelection,
  onSubmitSuccess,
}) => {
  const submitTimesheetMutation = useMutation({
    mutationFn: (timeLogIds: string[]) => {
      return Promise.all(timeLogIds.map((id) => submitTimesheet(id)));
    },
    onSuccess: () => {
      toast.success("Timesheets submitted successfully!");
      onSubmitSuccess();
    },
    onError: (error: any) => {
      toast.error(error?.message || "Failed to submit timesheets");
    },
  });

  const handleSubmitSelected = () => {
    if (selectedTimeLogIds.length === 0) {
      toast.error("Please select at least one timesheet to submit");
      return;
    }
    submitTimesheetMutation.mutate(selectedTimeLogIds);
  };

  return (
    <div className="space-y-4 rounded-lg border bg-white p-3 shadow-sm md:p-6">
      <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h3 className="flex items-center gap-2 text-lg font-semibold">
            <Calendar className="h-5 w-5" />
            Weekly Timesheet
          </h3>
          {weeklyTimesheet && (
            <p className="text-sm text-muted-foreground">
              {formatDate(weeklyTimesheet.weekStart)} -{" "}
              {formatDate(weeklyTimesheet.weekEnd)}
            </p>
          )}
        </div>
        {selectedTimeLogIds.length > 0 && (
          <Button
            onClick={handleSubmitSelected}
            disabled={submitTimesheetMutation.isPending}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Send className="mr-2 h-4 w-4" />
            {submitTimesheetMutation.isPending
              ? "Submitting..."
              : `Submit Selected (${selectedTimeLogIds.length})`}
          </Button>
        )}
      </div>

      {isLoading ? (
        <div className="py-8 text-center">
          <div className="mx-auto h-8 w-8 animate-spin rounded-full border-b-2 border-green-600"></div>
          <p className="mt-2 text-muted-foreground">
            Loading weekly timesheet...
          </p>
        </div>
      ) : isError ? (
        <p className="py-4 text-center text-red-500">
          Failed to load weekly timesheet.
        </p>
      ) : !weeklyTimesheet?.timesheet ||
        Object.keys(weeklyTimesheet.timesheet).length === 0 ? (
        <p className="py-4 text-center text-muted-foreground">
          No timesheet data available.
        </p>
      ) : (
        <div className="space-y-6">
          {Object.entries(weeklyTimesheet.timesheet).map(
            ([projectId, projectData]: [string, any]) => (
              <WeeklyTimesheetProject
                key={projectId}
                projectId={projectId}
                projectData={projectData}
                selectedTimeLogIds={selectedTimeLogIds}
                onTimeLogSelection={onTimeLogSelection}
              />
            ),
          )}
        </div>
      )}
    </div>
  );
};

export default WeeklyTimesheet;

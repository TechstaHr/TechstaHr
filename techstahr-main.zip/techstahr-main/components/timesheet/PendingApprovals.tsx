// components/PendingApprovals.tsx
"use client";

import React from "react";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";
import Image from "next/image";
import userIcon from "@/public/images/user-avatar.png";

interface PendingApprovalsProps {
  pendingInvitesResponse: any;
  isLoading: boolean;
  isError: boolean;
}

const PendingApprovals: React.FC<PendingApprovalsProps> = ({
  pendingInvitesResponse,
  isLoading,
  isError,
}) => {
  const pendingInvites = pendingInvitesResponse?.invitations ?? [];

  return (
    <div className="space-y-4 rounded-sm border bg-white p-2 shadow-sm lg:p-6">
      <h3 className="text-base font-medium">Pending Approvals</h3>

      {isLoading ? (
        <p className="text-muted-foreground">Loading pending invitations...</p>
      ) : isError ? (
        <p className="text-red-500">Failed to load pending invitations.</p>
      ) : pendingInvites.length === 0 ? (
        <p className="text-muted-foreground">No pending invitations found.</p>
      ) : (
        pendingInvites.map((pending: any) =>
          pending?.pendingMembers?.length > 0 ? (
            pending.pendingMembers.map((member: any) => {
              const { user, status, _id: pendingId } = member;

              return (
                <div
                  key={pendingId}
                  className="flex flex-col justify-between gap-4 rounded-sm border p-3 md:flex-row md:items-center"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-8 w-8 items-center justify-center overflow-hidden rounded-full">
                      <Image
                        src={user?.avatar || userIcon}
                        alt="user image"
                        className="w-full"
                        width={20}
                        height={20}
                      />
                    </div>
                    <div>
                      <p className="text-sm font-medium md:text-base">
                        {user?.full_name || user?.email || "Unknown User"}
                      </p>
                      <p className="text-xs text-muted-foreground md:text-sm">
                        Overtime: 2h 30m
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button className="bg-[#059669] text-white hover:bg-green-700">
                      <Check /> Approve
                    </Button>
                    <Button className="bg-[#DC2626] text-white hover:bg-red-700">
                      ✘ Reject
                    </Button>
                  </div>
                </div>
              );
            })
          ) : (
            <p
              key={pending.projectId}
              className="rounded border px-2 py-4 text-muted-foreground"
            >
              No pending members for project:{" "}
              <span className="font-medium">{pending.projectName}</span>
            </p>
          ),
        )
      )}
    </div>
  );
};

export default PendingApprovals;

// components/WeeklyTimesheetProject.tsx
"use client";

import React from "react";
import { Clock } from "lucide-react";
import TimeLogEntry from "./TimeLogEntry";

interface WeeklyTimesheetProjectProps {
  projectId: string;
  projectData: any;
  selectedTimeLogIds: string[];
  onTimeLogSelection: (logId: string) => void;
}

const WeeklyTimesheetProject: React.FC<WeeklyTimesheetProjectProps> = ({
  projectId,
  projectData,
  selectedTimeLogIds,
  onTimeLogSelection,
}) => {
  const getDayName = (day: string) => {
    const dayMap: { [key: string]: string } = {
      Mon: "Monday",
      Tue: "Tuesday",
      Wed: "Wednesday",
      Thu: "Thursday",
      Fri: "Friday",
      Sat: "Saturday",
      Sun: "Sunday",
    };
    return dayMap[day] || day;
  };

  return (
    <div className="rounded-lg border p-4">
      <h4 className="mb-4 text-lg font-medium text-blue-700">
        {projectData.projectName}
      </h4>

      {Object.entries(projectData.logsByDay).map(
        ([day, logs]: [string, any]) => (
          <div key={day} className="mb-4">
            <h5 className="mb-2 flex items-center gap-2 font-medium text-gray-700">
              <Clock className="h-4 w-4" />
              {getDayName(day)}
            </h5>
            <div className="space-y-2">
              {logs.map((log: any) => (
                <TimeLogEntry
                  key={log.logId}
                  log={log}
                  isSelected={selectedTimeLogIds.includes(log.logId)}
                  onSelection={onTimeLogSelection}
                />
              ))}
            </div>
          </div>
        ),
      )}
    </div>
  );
};

export default WeeklyTimesheetProject;

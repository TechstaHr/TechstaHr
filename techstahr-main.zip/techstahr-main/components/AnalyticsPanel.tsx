import { getPerformance } from "@/lib/actions/people.actions";
import { useQuery } from "@tanstack/react-query";

export const AnalyticsPanel = () => {
  const { data, isLoading, isError } = useQuery({
    queryKey: ["analytics"],
    queryFn: getPerformance,
  });

  const totalMinutes =
    data?.timeTracking?.reduce((sum, entry) => sum + entry.totalMinutes, 0) ||
    0;

  const hoursTracked = (totalMinutes / 60).toFixed(1);

  if (isError) {
    return (
      <div className="rounded-xl border p-6 text-center text-red-600">
        <p className="text-lg font-medium">Failed to load analytics data.</p>
        <p className="mt-1 text-sm text-gray-500">
          Please try refreshing the page.
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
      {/* Tasks Completed */}
      <div className="rounded-xl border p-4">
        <div className="mb-4 flex justify-between">
          <h4 className="font-medium">Tasks Completed</h4>
          <select className="bg-transparent text-sm outline-none">
            <option>This Week</option>
          </select>
        </div>

        {isLoading ? (
          <SkeletonBlock />
        ) : (
          <div className="flex items-center justify-between rounded-md border p-4">
            <div>
              <p className="text-sm text-gray-500">Tasks Completed</p>
              <p className="text-3xl font-bold">{data?.tasksCompleted || 0}</p>
              <p className="text-sm text-gray-400">from this week</p>
            </div>
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-green-100">
              <svg
                className="h-5 w-5 text-green-600"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M5 13l4 4L19 7"
                />
              </svg>
            </div>
          </div>
        )}
      </div>

      {/* Productivity Score */}
      <div className="rounded-xl border p-4">
        <div className="mb-4 flex justify-between">
          <h4 className="font-medium">Productivity Score</h4>
          <select className="bg-transparent text-sm outline-none">
            <option>Last 7 Days</option>
          </select>
        </div>

        {isLoading ? (
          <SkeletonList count={3} />
        ) : (
          <div className="space-y-2">
            {(data?.productivityScore.length > 0 &&
              data?.productivityScore?.map((item) => (
                <div
                  key={item._id}
                  className="flex items-center justify-between rounded-md bg-gray-50 p-3"
                >
                  <div className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-green-100">
                      <svg
                        className="h-4 w-4 text-green-600"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M5 13l4 4L19 7"
                        />
                      </svg>
                    </span>
                    <p className="text-sm">
                      {item.taskCount}{" "}
                      {item.taskCount === 1 ? "Project" : "Projects"} Completed
                    </p>
                  </div>
                </div>
              ))) || (
              <p className="text-sm text-gray-500">
                No productivity data available.
              </p>
            )}
          </div>
        )}
      </div>

      {/* Time Tracking */}
      <div className="rounded-xl border p-4">
        <div className="mb-4 flex justify-between">
          <h4 className="font-medium">Time Tracking</h4>
          <select className="bg-transparent text-sm outline-none">
            <option>Today</option>
          </select>
        </div>

        {isLoading ? (
          <SkeletonBlock />
        ) : (
          <div className="flex items-center justify-between rounded-md border p-4">
            <div>
              <p className="text-sm text-gray-500">Hours Tracked</p>
              <p className="text-3xl font-bold">{hoursTracked}h</p>
              <p className="text-sm text-gray-400">today</p>
            </div>
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-purple-100">
              <svg
                className="h-5 w-5 text-purple-600"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M12 6v6l4 2"
                />
                <circle cx="12" cy="12" r="10" />
              </svg>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

/**
 * Simple block skeleton loader
 */
const SkeletonBlock = () => (
  <div className="animate-pulse space-y-2 rounded-md border p-4">
    <div className="h-6 w-1/3 rounded bg-gray-200"></div>
    <div className="h-10 w-1/2 rounded bg-gray-200"></div>
    <div className="h-4 w-1/4 rounded bg-gray-200"></div>
  </div>
);

/**
 * Skeleton loader for a list of items
 */
const SkeletonList = ({ count = 3 }) => (
  <div className="space-y-2">
    {Array.from({ length: count }).map((_, idx) => (
      <div
        key={idx}
        className="flex animate-pulse items-center justify-between rounded-md bg-gray-100 p-3"
      >
        <div className="flex items-center gap-2">
          <div className="h-6 w-6 rounded-full bg-gray-300"></div>
          <div className="h-4 w-32 rounded bg-gray-300"></div>
        </div>
      </div>
    ))}
  </div>
);

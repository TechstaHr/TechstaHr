"use client";

import { TrendingUp } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid } from "recharts";

import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
} from "@/components/ui/card";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";
import { useQuery } from "@tanstack/react-query";
import { getAllProductivities } from "@/lib/actions/productivity.actions";
import { buildChartConfig, transformProductivityData } from "@/lib/utils";

const data = [
  { name: "Mon", uv: 400, pv: 240 },
  { name: "Tue", uv: 300, pv: 139 },
  { name: "Wed", uv: 200, pv: 980 },
  { name: "Thu", uv: 278, pv: 390 },
  { name: "Fri", uv: 189, pv: 480 },
];

const chartConfig = {
  uv: {
    label: "Unique Visitors",
    color: "var(--chart-1)",
  },
  pv: {
    label: "Page Views",
    color: "var(--chart-2)",
  },
};

export default function PerformanceChart() {
  const {
    data: allProductivity,
    isLoading,
    isError,
  } = useQuery({
    queryKey: ["allProductivity"],
    queryFn: getAllProductivities,
  });

  const chartData = allProductivity
    ? transformProductivityData(allProductivity)
    : [];

  const chartConfig = allProductivity ? buildChartConfig(allProductivity) : {};

  return (
    <Card>
      <CardHeader>
        <CardTitle>Performance Overview</CardTitle>
        <CardDescription>
          Productivity stats per user for the week
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading && <p>Loading chart...</p>}
        {isError && <p>Error loading data</p>}
        {!isLoading && !isError && (
          <ChartContainer config={chartConfig}>
            <LineChart
              accessibilityLayer
              data={chartData}
              margin={{ left: -20, right: 12 }}
              width={600}
              height={300}
            >
              <CartesianGrid vertical={false} strokeDasharray="3 3" />
              <XAxis
                dataKey="name"
                tickLine={false}
                axisLine={false}
                tickMargin={8}
              />
              <YAxis tickLine={false} axisLine={false} tickMargin={8} />
              <ChartTooltip cursor={false} content={<ChartTooltipContent />} />
              {Object.entries(chartConfig).map(([key, config]) => (
                <Line
                  key={key}
                  type="monotone"
                  dataKey={key}
                  stroke={config.color}
                  strokeWidth={2}
                />
              ))}
            </LineChart>
          </ChartContainer>
        )}
      </CardContent>
      <CardFooter>
        <div className="flex w-full items-start gap-2 text-sm">
          <div className="grid gap-2">
            <div className="flex items-center gap-2 font-medium leading-none">
              Productivity overview <TrendingUp className="h-4 w-4" />
            </div>
            <div className="flex items-center gap-2 leading-none text-muted-foreground">
              Monday - Friday
            </div>
          </div>
        </div>
      </CardFooter>
    </Card>
  );
}

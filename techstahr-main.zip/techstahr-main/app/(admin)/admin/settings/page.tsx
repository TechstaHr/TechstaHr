"use client";

import React from "react";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { ChevronDown, EllipsisVertical } from "lucide-react";
import slackLogo from "@/public/icons/slack_logo.png";
import jiraLogo from "@/public/icons/jira_logo.png";
import Image from "next/image";
import atmCard from "@/public/images/atm_card.png";
import visaCard from "@/public/images/visa_card.png";

const Settings = () => {
  return (
    <div className="mx-auto max-w-6xl space-y-4 p-4">
      {/* Project Preferences */}
      <Card className="space-y-4 p-6">
        <h2 className="text-lg font-semibold">Project Preferences</h2>

        <div className="space-y-3">
          <div className="flex items-center justify-between rounded-sm bg-[#F9FAFB] p-4">
            <div className="flex items-center gap-2">
              <span className="h-3 w-3 rounded-full bg-[#FBBF24]" />
              <p>In Progress</p>
            </div>
            <EllipsisVertical size={16} />
          </div>
          <div className="flex items-center justify-between rounded-sm bg-[#F9FAFB] p-4">
            <div className="flex items-center gap-2">
              <span className="h-3 w-3 rounded-full bg-green-500" />
              <p>Completed</p>
            </div>
            <EllipsisVertical size={16} />
          </div>
          <div className="flex items-center justify-between rounded-sm bg-[#F9FAFB] p-4">
            <div className="flex items-center gap-2">
              <span className="h-3 w-3 rounded-full bg-red-500" />
              <p>Blocked</p>
            </div>
            <EllipsisVertical size={16} />
          </div>

          <button className="text-sm font-medium text-blue-600 hover:underline">
            + Add New Status
          </button>
        </div>

        <div className="mt-6 space-y-2">
          <p className="font-medium">Workflow Settings</p>
          <div className="flex items-center justify-between">
            <p>Enable task dependencies</p>
            <Switch defaultChecked />
          </div>
          <div className="flex items-center justify-between">
            <p>Allow subtasks creation</p>
            <Switch defaultChecked />
          </div>
        </div>

        <div className="mt-6 space-y-2">
          <p className="font-medium">Deadline Settings</p>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="flex flex-col">
              <p>Default due time</p>
              <div className="flex items-center justify-between gap-1 rounded-md border px-2 py-1 text-sm text-gray-700">
                5:00 PM <ChevronDown size={14} />
              </div>
            </div>
            <div className="flex flex-col">
              <p>Deadline reminder</p>
              <div className="flex items-center justify-between gap-1 rounded-md border px-2 py-1 text-sm text-gray-700">
                24 hours before <ChevronDown size={14} />
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Workload Management */}
      <Card className="space-y-4 p-6">
        <h2 className="text-lg font-semibold">Workload Management</h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          {[
            { name: "John Doe", tasks: 8 },
            { name: "Jane Smith", tasks: 5 },
            { name: "Mike Johnson", tasks: 3 },
          ].map((user) => (
            <div
              key={user.name}
              className="space-y-2 rounded-sm bg-[#F9FAFB] p-4"
            >
              <div className="flex items-center justify-between">
                <p className="font-medium">{user.name}</p>
                <p className="text-sm text-muted-foreground">
                  {user.tasks} tasks
                </p>
              </div>
              <div className="h-2 w-full overflow-hidden rounded-full bg-gray-200">
                <div
                  className="h-full bg-green-500"
                  style={{ width: `${user.tasks * 10}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Notifications & Alerts */}
      <Card className="space-y-4 p-6">
        <h2 className="text-lg font-semibold">Notifications & Alerts</h2>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Email Notifications</p>
              <p className="text-sm text-muted-foreground">
                Receive updates via email
              </p>
            </div>
            <Switch defaultChecked />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Desktop Notifications</p>
              <p className="text-sm text-muted-foreground">
                Show browser notifications
              </p>
            </div>
            <Switch defaultChecked />
          </div>
        </div>
      </Card>

      {/* Integration Settings */}
      <Card className="space-y-4 p-6">
        <h2 className="text-lg font-semibold">Integration Settings</h2>
        <div className="space-y-3">
          <div className="flex items-center justify-between rounded-md border p-4">
            <div className="flex items-center gap-2">
              <Image src={slackLogo} alt="slack logo" />
              <div>
                <p className="font-medium">Slack</p>
                <p className="text-sm">Connected</p>
              </div>
            </div>
            <button className="font-medium text-red-600">Disconnect</button>
          </div>
          <div className="flex items-center justify-between rounded-md border p-4">
            <div className="flex items-center gap-2">
              <Image src={jiraLogo} alt="jira logo" />
              <div>
                <p className="font-medium">Jira</p>
                <p className="text-sm text-gray-400">Not connected</p>
              </div>
            </div>
            <button className="font-medium text-blue-600">Connect</button>
          </div>
        </div>
      </Card>

      {/* Billing & Subscription */}
      <Card className="space-y-4 p-6">
        <h2 className="text-lg font-semibold">Billing & Subscription</h2>

        <div className="flex flex-col rounded-md border p-4 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="font-medium">Current Plan</p>
            <p className="text-green-600">Premium</p>
            <div className="flex items-center gap-2">
              <Image src={atmCard} alt="atm card" />
              <p className="text-sm text-muted-foreground">
                Billing cycle: Monthly
              </p>
            </div>
          </div>
          <Button className="mt-2 rounded-sm bg-green-600 text-white hover:bg-green-700 md:mt-0">
            Upgrade Plan
          </Button>
        </div>

        <div className="flex items-center justify-between rounded-md border p-4">
          <div>
            <p className="text-sm text-muted-foreground">Payment Method</p>
            <div className="flex items-center gap-2">
              <Image src={visaCard} alt="visa card" />
              <p className="font-medium">•••• •••• •••• 4242</p>
            </div>
          </div>
          <button className="font-medium text-green-600">Edit</button>
        </div>
      </Card>
    </div>
  );
};

export default Settings;

import React from "react";
import Image from "next/image";
import { Plus, CopyIcon, Pencil } from "lucide-react";
import { IntegrationCard } from "@/components/cards/IntegrationCard";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import slackIcon from "@/public/icons/slack_logo.png";
import githubIcon from "@/public/icons/github.png";
import trelloIcon from "@/public/icons/trello.png";
import githubPreview from "@/public/icons/github_integration.png";
import slackPreview from "@/public/icons/slack_integration.png";

const AdminActivity = () => {
  return (
    <div className="space-y-8 px-4 py-6">
      {/* Integration Screenshots */}
      <div>
        <h2 className="mb-3 text-lg font-semibold">Integration Screenshots</h2>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div className="overflow-hidden rounded-sm border bg-white">
            <Image
              src={slackPreview}
              alt="Slack Screenshot"
              className="h-auto w-full"
            />
            <div className="p-3">
              <p className="font-medium">Slack Integration</p>
              <p className="text-sm text-muted-foreground">
                Message synchronization and channel management
              </p>
            </div>
          </div>
          <div className="overflow-hidden rounded-sm border bg-white">
            <Image
              src={githubPreview}
              alt="GitHub Screenshot"
              className="h-auto w-full"
            />
            <div className="p-3">
              <p className="font-medium">GitHub Integration</p>
              <p className="text-sm text-muted-foreground">
                Repository access and commit tracking
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Integrated Applications */}
      <div>
        <h2 className="mb-3 text-lg font-semibold">Integrated Applications</h2>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4">
          <IntegrationCard
            icon={slackIcon}
            name="Slack"
            description="Connected and actively syncing"
            status="Connected"
          />
          <IntegrationCard
            icon={githubIcon}
            name="GitHub"
            description="Repository access enabled"
            status="Connected"
          />
          <IntegrationCard
            icon={trelloIcon}
            name="Trello"
            description="Board synchronization active"
            status="Connected"
          />
          <div className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-lg border border-dashed border-[#AAAAAA] p-5 hover:bg-muted/50">
            <div className="rounded-full bg-[#EFF6FF] p-3">
              <Plus stroke="#2563EB" />
            </div>
            <p className="text-lg font-medium">Add More Apps</p>
            <p className="text-[#6B7280]">Browse our app marketplace</p>
          </div>
        </div>
      </div>

      {/* Integration URLs */}
      <div>
        <h2 className="mb-3 text-lg font-semibold">Integration URLs</h2>
        <div className="overflow-hidden rounded-lg border">
          <table className="w-full bg-white text-sm">
            <thead className="bg-[#F9FAFB] text-muted-foreground">
              <tr className="text-left font-medium">
                <th className="px-4 py-2">Application</th>
                <th className="px-4 py-2">Endpoint URL</th>
                <th className="px-4 py-2">Status</th>
                <th className="px-4 py-2">Actions</th>
              </tr>
            </thead>
            <tbody>
              {/* Slack Row */}
              <tr className="border-t">
                <td className="flex items-center gap-2 px-4 py-3">
                  <Image src={slackIcon} alt="slack logo" className="w-5" />
                  <p>Slack</p>
                </td>
                <td className="px-4 py-3">
                  <Input value="https://api.slack.com/webhook/xyz" readOnly />
                </td>
                <td className="px-4 py-3">
                  <Badge
                    variant="outline"
                    className="bg-[#D1FAE5] text-[#065F46]"
                  >
                    Active
                  </Badge>
                </td>
                <td className="px-4 py-3">
                  <div className="flex gap-2">
                    <Button size="icon" variant="ghost">
                      <CopyIcon
                        className="h-4 w-4"
                        stroke="#4CAF50"
                        fill="#4CAF50"
                      />
                    </Button>
                    <Button size="icon" variant="ghost">
                      <Pencil
                        className="h-4 w-4 text-[#4CAF50]"
                        fill="#4CAF50"
                      />
                    </Button>
                  </div>
                </td>
              </tr>

              {/* GitHub Row */}
              <tr className="border-t">
                <td className="flex items-center gap-2 px-4 py-3">
                  <Image src={githubIcon} alt="github logo" className="w-5" />
                  <p>GitHub</p>
                </td>
                <td className="px-4 py-3">
                  <Input value="https://api.github.com/webhooks/abc" readOnly />
                </td>
                <td className="px-4 py-3">
                  <Badge
                    variant="outline"
                    className="bg-[#D1FAE5] text-[#065F46]"
                  >
                    Active
                  </Badge>
                </td>
                <td className="px-4 py-3">
                  <div className="flex gap-2">
                    <Button size="icon" variant="ghost">
                      <CopyIcon
                        className="h-4 w-4"
                        stroke="#4CAF50"
                        fill="#4CAF50"
                      />
                    </Button>
                    <Button size="icon" variant="ghost">
                      <Pencil
                        className="h-4 w-4 text-[#4CAF50]"
                        fill="#4CAF50"
                      />
                    </Button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminActivity;

import Invitations from "@/components/Invitations";
import ProjectModification from "@/components/ProjectModification";

const InvitationsPage = () => {
  return (
    <div className="space-y-12 px-4 py-6">
      <Invitations />
      <ProjectModification />
    </div>
  );
};

export default InvitationsPage;

"use client";

import React, { useEffect, useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import PaystackForm from "@/components/PaystackForm";
import toast from "react-hot-toast";
import {
  createBillingInfo,
  getBillingInfo,
  updateBillingInfo,
} from "@/lib/actions/billing.actions";
import { BillingInfo } from "@/types";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";

const Billing = () => {
  const [form, setForm] = useState<BillingInfo>({
    companyName: "",
    taxId: "",
    billingEmail: "",
    phoneNumber: "",
    address: {
      street: "",
      city: "",
      state: "",
      postalCode: "",
      country: "",
    },
  });

  const queryClient = useQueryClient();

  const {
    data: billingData,
    isLoading,
    isError,
  } = useQuery({
    queryKey: ["billingInfo"],
    queryFn: getBillingInfo,
    staleTime: 5 * 60 * 1000,
    retry: false,
  });

  const isCreating = isError || !billingData;

  const createMutation = useMutation({
    mutationFn: createBillingInfo,
    onSuccess: (data) => {
      toast.success(data.message || "Billing info created successfully");
      queryClient.invalidateQueries({ queryKey: ["billingInfo"] });
    },
    onError: (error: any) => {
      toast.error(error?.message || "Failed to create billing info");
    },
  });

  const updateMutation = useMutation({
    mutationFn: updateBillingInfo,
    onSuccess: (data) => {
      toast.success(data.message || "Billing info updated successfully");
      queryClient.invalidateQueries({ queryKey: ["billingInfo"] });
    },
    onError: (error: any) => {
      toast.error(error?.message || "Failed to update billing info");
    },
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target;
    if (["street", "city", "state", "postalCode", "country"].includes(id)) {
      setForm((prev) => ({
        ...prev,
        address: {
          ...prev.address,
          [id]: value,
        },
      }));
    } else {
      setForm((prev) => ({ ...prev, [id]: value }));
    }
  };

  const handleSave = async () => {
    if (isCreating) {
      createMutation.mutate(form);
    } else {
      updateMutation.mutate(form);
    }
  };

  useEffect(() => {
    if (billingData && !isError) {
      setForm(billingData);
    }
  }, [billingData, isError]);

  const isSaving = createMutation.isPending || updateMutation.isPending;
  const getButtonText = () => {
    if (isSaving) {
      return isCreating ? "Creating..." : "Updating...";
    }
    return isCreating ? "Save Information" : "Update Information";
  };

  return (
    <div className="max-w-5xl space-y-8 px-4 py-6">
      {/* Payment Methods */}
      <PaystackForm />

      {/* Auto-Renewal */}
      <Card className="flex items-center justify-between bg-white p-4">
        <div>
          <h3 className="font-medium">Auto-Renewal</h3>
          <p className="text-sm text-muted-foreground">
            Your subscription will automatically renew on May 15, 2025
          </p>
        </div>
        <Switch defaultChecked className="data-[state=checked]:bg-[#4CAF50]" />
      </Card>

      {/* Billing Contact Information */}
      <Card className="space-y-6 bg-white p-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Billing Contact Information</h2>
          {isLoading && (
            <div className="text-sm text-muted-foreground">Loading...</div>
          )}
          {isCreating && !isLoading && (
            <div className="text-sm text-blue-600">
              Creating new billing info
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div>
            <Label htmlFor="companyName">Company Name</Label>
            <Input
              id="companyName"
              value={form.companyName}
              onChange={handleChange}
              disabled={isLoading}
            />
          </div>
          <div>
            <Label htmlFor="taxId">Tax ID/VAT Number</Label>
            <Input
              id="taxId"
              value={form.taxId}
              onChange={handleChange}
              disabled={isLoading}
            />
          </div>
          <div>
            <Label htmlFor="billingEmail">Billing Email</Label>
            <Input
              id="billingEmail"
              value={form.billingEmail}
              onChange={handleChange}
              disabled={isLoading}
            />
          </div>
          <div>
            <Label htmlFor="phoneNumber">Phone Number</Label>
            <Input
              id="phoneNumber"
              value={form.phoneNumber}
              onChange={handleChange}
              disabled={isLoading}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <Label>Billing Address</Label>
          <div className="md:col-span-2">
            <Input
              id="street"
              value={form.address.street}
              onChange={handleChange}
              placeholder="Street Address"
              disabled={isLoading}
            />
          </div>
          <Input
            id="city"
            value={form.address.city}
            onChange={handleChange}
            placeholder="City"
            disabled={isLoading}
          />
          <Input
            id="state"
            value={form.address.state}
            onChange={handleChange}
            placeholder="State"
            disabled={isLoading}
          />
          <Input
            id="postalCode"
            value={form.address.postalCode}
            onChange={handleChange}
            placeholder="Postal Code"
            disabled={isLoading}
          />
          <Input
            id="country"
            value={form.address.country}
            onChange={handleChange}
            placeholder="Country"
            disabled={isLoading}
          />
        </div>

        <div className="flex justify-end gap-4">
          <Button variant="outline" className="rounded-sm">
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            disabled={isSaving || isLoading}
            className="rounded-sm bg-[#4CAF50] text-white hover:bg-green-700"
          >
            {getButtonText()}
          </Button>
        </div>
      </Card>
    </div>
  );
};

export default Billing;

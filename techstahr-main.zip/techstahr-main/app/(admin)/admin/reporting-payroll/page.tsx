import React from "react";
import upcomingPayrollIcon from "@/public/icons/upcoming.png";
import totalPayrollIcon from "@/public/icons/total_payroll.png";
import pendingApproval from "@/public/icons/pending_approval.png";
import payrollSummary from "@/public/icons/summary.png";
import costAllocation from "@/public/icons/allocation.png";
import reportBuilder from "@/public/icons/builder.png";
import peopleConfig from "@/public/icons/people_config.png";
import systemSettings from "@/public/icons/system_settings.png";

import { PayrollStatCard } from "@/components/cards/PayrollStatCard";
import { ReportOptionCard } from "@/components/cards/ReportOptionCard";
import Image from "next/image";

const ReportingPayroll = () => {
  return (
    <div className="space-y-8 px-4 py-2">
      {/* Top Cards */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        <PayrollStatCard
          icon={upcomingPayrollIcon}
          title="Upcoming Payroll"
          value="$247,890"
          subtitle="Due on Apr 25, 2025"
        />
        <PayrollStatCard
          icon={totalPayrollIcon}
          title="Total Payroll"
          value="$1,234,567"
          subtitle="Current month"
        />
        <PayrollStatCard
          icon={pendingApproval}
          title="Pending Approvals"
          value="12"
          subtitle="Requires attention"
        />
      </div>

      {/* Reporting Options */}
      <div>
        <h2 className="mb-3 text-lg font-semibold">Reporting Options</h2>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <ReportOptionCard
            icon={payrollSummary}
            title="Payroll Summary"
            description="View comprehensive payroll reports and analytics"
            actionText="Generate Report"
          />
          <ReportOptionCard
            icon={costAllocation}
            title="Project Cost Allocation"
            description="Track project-wise cost distribution"
            actionText="View Allocation"
          />
          <ReportOptionCard
            icon={reportBuilder}
            title="Custom Report Builder"
            description="Create customized reports for your needs"
            actionText="Build Report"
          />
        </div>
      </div>

      {/* Quick Links */}
      <div className="rounded-sm bg-white p-4">
        <h2 className="mb-3 text-lg font-semibold">Quick Links</h2>
        <div className="flex flex-col items-center justify-between gap-4 bg-white p-4 lg:flex-row">
          <div className="flex items-center gap-3">
            <Image src={peopleConfig} alt="config icon" />
            <div>
              <strong>People Configuration:</strong>
              <p className="text-sm text-muted-foreground">
                Manage employee payroll settings
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Image src={systemSettings} alt="settings icon" />
            <div>
              <strong>System Settings:</strong>
              <p className="text-sm text-muted-foreground">
                Configure payroll system preferences
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReportingPayroll;

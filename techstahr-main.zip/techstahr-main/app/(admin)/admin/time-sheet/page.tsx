// Main TimeSheet Component
"use client";

import React from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  getAllProjects,
  getPendingInvitations,
} from "@/lib/actions/project.actions";
import {
  getTimesheets,
  getWeeklyTimeSheet,
} from "@/lib/actions/timesheet.actions";
import TimeTrackingHeader from "@/components/timesheet/TimeTrackingHeader";
import ManualTimeEntry from "@/components/timesheet/ManualTimeEntry";
import WeeklyTimesheet from "@/components/timesheet/WeeklyTimesheet";
import SubmittedTimesheets from "@/components/timesheet/SubmittedTimesheets";
import ProjectSummaries from "@/components/timesheet/ProjectSummaries";
import PendingApprovals from "@/components/timesheet/PendingApprovals";

const TimeSheet = () => {
  const userId = "68648d3c0906dad02243d2e3";
  const projectId = "6862e6a9455ab459e34ed64f";
  const [selectedTimeLogIds, setSelectedTimeLogIds] = React.useState<string[]>(
    [],
  );

  const queryClient = useQueryClient();

  // Queries
  const { data: projects } = useQuery({
    queryKey: ["all-projects"],
    queryFn: () => getAllProjects(),
  });

  const {
    data: pendingInvitesResponse,
    isLoading: isLoadingPending,
    isError: isErrorPending,
  } = useQuery({
    queryKey: ["pending-invitations"],
    queryFn: getPendingInvitations,
  });

  const {
    data: weeklyTimesheet,
    isLoading: isLoadingWeekly,
    isError: isErrorWeekly,
  } = useQuery({
    queryKey: ["weekly-timesheet"],
    queryFn: getWeeklyTimeSheet,
  });

  const {
    data: submittedTimesheets,
    isLoading: isLoadingSubmitted,
    isError: isErrorSubmitted,
  } = useQuery({
    queryKey: ["submitted-timesheets"],
    queryFn: getTimesheets,
  });

  const handleTimeLogSelection = (logId: string) => {
    setSelectedTimeLogIds((prev) =>
      prev.includes(logId)
        ? prev.filter((id) => id !== logId)
        : [...prev, logId],
    );
  };

  const handleSubmitSuccess = () => {
    setSelectedTimeLogIds([]);
    queryClient.invalidateQueries({ queryKey: ["submitted-timesheets"] });
    queryClient.invalidateQueries({ queryKey: ["weekly-timesheet"] });
  };

  return (
    <div className="space-y-4 p-4">
      {/* <TimeTrackingHeader userId={userId} projectId={projectId} /> */}

      {/* <ManualTimeEntry /> */}

      <WeeklyTimesheet
        weeklyTimesheet={weeklyTimesheet}
        isLoading={isLoadingWeekly}
        isError={isErrorWeekly}
        selectedTimeLogIds={selectedTimeLogIds}
        onTimeLogSelection={handleTimeLogSelection}
        onSubmitSuccess={handleSubmitSuccess}
      />

      <SubmittedTimesheets
        submittedTimesheets={submittedTimesheets}
        isLoading={isLoadingSubmitted}
        isError={isErrorSubmitted}
      />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <ProjectSummaries projects={projects} />

        <PendingApprovals
          pendingInvitesResponse={pendingInvitesResponse}
          isLoading={isLoadingPending}
          isError={isErrorPending}
        />
      </div>
    </div>
  );
};

export default TimeSheet;

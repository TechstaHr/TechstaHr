"use client";

import React, { useState, useEffect } from "react";
import CalendarNav from "@/components/CalendarNav";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ProjectProps } from "@/types";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  getTimeSheet,
  startProjectTimer,
  stopProjectTimer,
} from "@/lib/actions/timer.actions";
import toast from "react-hot-toast";
import { useTimerStore } from "@/store/timerStore";
import { formatTime } from "@/lib/utils";
import { getUserProjects } from "@/lib/actions/project.actions";

const TimeTracking = () => {
  const {
    data: userProject,
    isLoading: projectsLoading,
    error: projectsError,
  } = useQuery({
    queryKey: ["user-projects"],
    queryFn: getUserProjects,
  });

  const projects = userProject?.projects || [];

  const { data, isLoading, error } = useQuery({
    queryKey: ["timeSheet"],
    queryFn: getTimeSheet,
  });

  const {
    isRunning,
    elapsed,
    start,
    stop,
    setProjectId,
    reset,
    projectId,
    startTime,
    stopTime,
    selectedProject,
    setSelectedProject,
  } = useTimerStore();

  // Use selectedProject from store, fallback to local state
  const [localProject, setLocalProject] = useState<ProjectProps | null>(
    selectedProject,
  );
  const [description, setDescription] = useState(
    selectedProject?.description || "",
  );

  const queryClient = useQueryClient();

  // Sync with store when selectedProject changes
  useEffect(() => {
    if (selectedProject) {
      setLocalProject(selectedProject);
      setDescription(
        selectedProject.description || "No description for this project",
      );
    }
  }, [selectedProject]);

  const { mutate: startTimerMutate, isPending: isStarting } = useMutation({
    mutationFn: startProjectTimer,
    onSuccess: (data) => {
      toast.success(data?.message);
      queryClient.invalidateQueries({ queryKey: ["timeSheet"] });
    },
    onError: (error) => {
      console.error("Start timer error:", error);
    },
  });

  const { mutate: stopTimerMutate, isPending: isStopping } = useMutation({
    mutationFn: stopProjectTimer,
    onSuccess: (data) => {
      toast.success(data?.message);
      queryClient.invalidateQueries({ queryKey: ["timeSheet"] });
    },
    onError: (error) => {
      console.error("Stop timer error:", error);
    },
  });

  const handleStart = () => {
    if (!localProject) return toast.error("Please select a project first.");
    setProjectId(localProject._id);
    setSelectedProject(localProject);
    start();
    startTimerMutate(localProject._id);
  };

  const handleStop = () => {
    if (!projectId) return toast.error("No project running.");
    stop();
    stopTimerMutate(projectId);
    reset();
  };

  const handleProjectChange = (value: string) => {
    const selectedProj = projects.find((p) => p._id === value);
    if (selectedProj) {
      setLocalProject(selectedProj);
      setSelectedProject(selectedProj);
      setDescription(
        selectedProj.description || "No description for this project",
      );
    }
  };

  const days = ["Mon", "Tue", "Wed", "Thu", "Fri"];

  useEffect(() => {
    if (isRunning && startTime) {
      const interval = setInterval(() => {
        const currentElapsed = Math.floor((Date.now() - startTime) / 1000);
        useTimerStore.setState({ elapsed: currentElapsed });
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [isRunning, startTime]);

  return (
    <div className="space-y-8 px-4">
      <h2 className="font-inter text-2xl font-medium">Time Tracking</h2>
      <CalendarNav />

      <div className="w-full rounded-sm border p-5 lg:p-8">
        <div className="space-y-8">
          <div className="w-full md:w-1/2">
            <Label>Project Name</Label>
            {projectsError && <p>Couldn&apos;t get projects</p>}
            <Select
              value={localProject?._id || ""}
              onValueChange={handleProjectChange}
            >
              <SelectTrigger className="rounded-sm">
                <SelectValue
                  placeholder={
                    projectsLoading ? "Loading..." : "--Select Project--"
                  }
                />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  {projects?.length > 0 &&
                    projects?.map((item) => (
                      <SelectItem key={item._id} value={item._id}>
                        {item.name}
                      </SelectItem>
                    ))}
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
          <div className="w-full rounded-sm px-2 md:w-1/2">
            <span className="font-semibold">Description:</span>{" "}
            {description || "Select a project to see description."}
          </div>

          <div className="flex items-center justify-start gap-4">
            <Button
              className="rounded-sm bg-[#4CAF50] lg:w-[160px]"
              onClick={handleStart}
              disabled={isRunning}
            >
              {isStarting ? "Starting..." : "Start"}
            </Button>
            <Button
              className="rounded-sm bg-[#F00000] lg:w-[160px]"
              onClick={handleStop}
              disabled={!isRunning}
            >
              {isStopping ? "Stopping" : "Stop"}
            </Button>

            <p className="text-lg font-semibold">{formatTime(elapsed)}</p>
            {startTime && (
              <p className="text-sm text-gray-500">
                Started at: {new Date(startTime).toLocaleTimeString()}
              </p>
            )}
            {stopTime && (
              <p className="text-sm text-gray-500">
                Stopped at: {new Date(stopTime).toLocaleTimeString()}
              </p>
            )}
          </div>
        </div>

        <hr className="my-8 h-0.5 w-full" />

        <div className="space-y-4 overflow-x-auto">
          <h2 className="text-xl font-medium">Timesheet View</h2>

          <div className="hide-scrollbar w-full overflow-x-auto">
            <table className="w-full min-w-[600px] table-auto border text-sm">
              <thead className="bg-gray-100">
                <tr>
                  <th className="border px-4 py-2">Project</th>
                  {days.map((day) => (
                    <th key={day} className="border px-4 py-2">
                      {day}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {isLoading && <tr>Loading Timesheet...</tr>}
                {error && <tr>Failed to load timesheet</tr>}

                {data &&
                  Object.entries(data.timesheet).map(([, entry], index) => (
                    <tr key={index}>
                      <td className="border px-4 py-2 align-top">
                        <p className="text-lg font-semibold">
                          {entry.projectName}
                        </p>
                      </td>
                      {days.map((day) => (
                        <td key={day} className="border px-4 py-2 align-top">
                          {entry.logsByDay[day] ? (
                            entry.logsByDay[day].map((log, i) => {
                              const start = new Date(
                                log.start,
                              ).toLocaleTimeString([], {
                                hour: "2-digit",
                                minute: "2-digit",
                              });
                              const end = new Date(log.end).toLocaleTimeString(
                                [],
                                {
                                  hour: "2-digit",
                                  minute: "2-digit",
                                },
                              );
                              return (
                                <div key={i} className="mb-1">
                                  <p className="text-xs text-[#AAAAAA]">
                                    Start:{" "}
                                    <span className="text-black">{start}</span>
                                  </p>
                                  <p className="text-xs text-[#AAAAAA]">
                                    Stop:{" "}
                                    <span className="text-black">{end}</span>
                                  </p>
                                  <hr className="my-1" />
                                </div>
                              );
                            })
                          ) : (
                            <>
                              <p className="text-xs text-[#AAAAAA]">
                                Start: ---
                              </p>
                              <p className="text-xs text-[#AAAAAA]">
                                Stop: ---
                              </p>
                            </>
                          )}
                        </td>
                      ))}
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TimeTracking;

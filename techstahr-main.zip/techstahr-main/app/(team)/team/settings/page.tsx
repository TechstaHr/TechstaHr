import SettingsTabs from "@/components/SettingsTabs";
import React from "react";

const Settings = () => {
  return (
    <div className="py-5">
      <div>
        <SettingsTabs />
      </div>
    </div>
  );
};

export default Settings;

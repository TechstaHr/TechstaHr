import { PaymentCard } from "@/components/PaymentCard";
import PaymentNav from "@/components/PaymentNav";
import React from "react";
import hourglass from "@/public/icons/hour-glass.svg";
import nairaImg from "@/public/icons/naira.svg";
import time from "@/public/icons/time.svg";

const paymentOptions = [
  {
    title: "Total Hours Tracked",
    icon: hourglass,
    description: "42.5 hours",
  },
  {
    title: "Pay Rate",
    icon: nairaImg,
    description: "₦2000.00/hr",
    secondImage: "/hourglass.png",
  },
  {
    title: "Payment Status",
    icon: time,
    description: "Pending",
  },
];

const Payments = () => {
  return (
    <div className="space-y-10 px-4">
      <h2 className="text-2xl font-medium text-[#333333]">Payments</h2>
      <PaymentNav />
      <div className="grid grid-cols-1 items-center justify-between gap-5 lg:grid-cols-3">
        {paymentOptions.map((item, index) => (
          <PaymentCard
            key={index}
            title={item.title}
            text={item.description}
            picture={item.icon}
          />
        ))}
      </div>
    </div>
  );
};

export default Payments;

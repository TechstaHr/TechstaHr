require('dotenv').config();
const mongoose = require("mongoose");
const MyTask = require("../models/MyTask");

const connectDB = async () => {
  try {
    await mongoose.connect(process.env.DATABASE_URL);
    console.log("✅ Connected to MongoDB");
  } catch (err) {
    console.error("❌ MongoDB connection error:", err.message);
    process.exit(1);
  }
};

const disableAllScreenshots = async () => {
  try {
    const result = await MyTask.updateMany(
      { enableScreenshot: true },
      {
        $set: {
          enableScreenshot: false,
          nextScreenshotAt: null,
        },
        $unset: {
          screenshotIntervalMinutes: '',
        },
      }
    );

    console.log(`✅ Disabled screenshots on ${result.modifiedCount} task(s).`);
    process.exit(0);
  } catch (err) {
    console.error("❌ Error disabling screenshots:", err.message);
    process.exit(1);
  }
};

(async () => {
  await connectDB();
  await disableAllScreenshots();
})();

require('dotenv').config();
const bcrypt = require('bcrypt');
const ConnectDB = require('../config/db');
const User = require('../models/User');

const createAdmin = async () => {
    await ConnectDB();

    const email = 'admin@example.com';
    const password = 'admin@123';

    const existing = await User.findOne({ email });
    if (existing) {
        console.log('⚠️ Admin already exists');
        return process.exit(0);
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const admin = new User({
        first_name: 'Super',
        last_name: 'Admin',
        email,
        password: hashedPassword,
        role: 'admin',
        online: false
    });

    await admin.save();

    console.log(`✅ Admin created: ${email}`);
    process.exit(0);
};

createAdmin().catch(err => {
    console.error('❌ Failed to create admin:', err);
    process.exit(1);
});
